# at first open virtual environment
workon cv
# then run this command
python facial_landmarks.py --shape-predictor shape_predictor_68_face_landmarks.dat --image images/example_01.jpg
